Homika Pro Patch 13A.2
Trial response isolation + activation theme contrast fix.

Changes:
- Root activation screen now owns Material theme background/content colors.
- Explicit high-contrast text colors for headings and secondary text.
- Trial card/input and paid-plan card use theme-safe surface colors.
- Adds status/navigation bar safe padding so lower licence controls are not hidden.
- Trial endpoint errors can no longer fall through to generic "Licence not accepted".
- Unknown trial HTTP errors are mapped to a trial-specific server error.
- 404 trial endpoint gets a specific backend-update message.
- Worker health version 11 with trial response contract 2.
- No D1 migration.
- No sync engine, backup engine, updater workflow, or signing changes.
